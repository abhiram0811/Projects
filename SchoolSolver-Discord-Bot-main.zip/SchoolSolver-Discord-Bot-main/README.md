# SchoolSolver-Discord-Bot
A cloud based Web Scraping discord bot which sends a message in channel regarding the question details, whenever a new question is added in the School Solver Website.

The bot is based on a cloud based platform, Replit(https://replit.com/~) which is a very useful website. It allows free running of code for an hour on a free plan. So, I created a simple web server for the bot using Flask and then ping it continiously for every five minutes using uprising bot (https://uptimerobot.com/dashboard#788400819), so that the bot runs forever.
